A light weight computer science quiz hosted in the terminal


